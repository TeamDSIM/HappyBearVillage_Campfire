// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/HBAttackAnimationInterface.h"

// Add default functionality here for any IHBAttackAnimationInterface functions that are not pure virtual.
