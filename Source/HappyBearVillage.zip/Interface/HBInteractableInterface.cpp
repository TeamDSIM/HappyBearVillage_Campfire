// Fill out your copyright notice in the Description page of Project Settings.


#include "Interface/HBInteractableInterface.h"

// Add default functionality here for any IHBInteractableInterface functions that are not pure virtual.
