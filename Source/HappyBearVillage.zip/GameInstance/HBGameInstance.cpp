// Fill out your copyright notice in the Description page of Project Settings.


#include "HBGameInstance.h"
#include "Controller/HBPlayerController.h"
#include "Kismet/GameplayStatics.h"

UHBGameInstance::UHBGameInstance()
{

}

void UHBGameInstance::Init()
{
	Super::Init();
	FCoreUObjectDelegates::PostLoadMapWithWorld.AddUObject(this, &UHBGameInstance::OnPostLoadMap);
}


void UHBGameInstance::OnPostLoadMap(UWorld* World)
{
    UE_LOG(LogTemp, Log, TEXT("OnPostLoadMap Loaded"));

    if (!World)
    {
        return;
    }
    bNewMapLoad = true;

    //FirstPlayerController �� ��������, client �� PC�� �ƴ� host�� PC�� ������
    //�ٵ� 0���� �ڱⲨ�´µ�?
    //"Local"�� PC�� �����;� ��..?
    //APlayerController* PC = World->GetFirstPlayerController();
    //APlayerController* PC = UGameplayStatics::GetPlayerController(World, 0);
    //AHBPlayerController* HBPC = Cast<AHBPlayerController>(PC);
    //if (!HBPC || !HBPC->IsLocalController())
    //{
    //    UE_LOG(LogTemp, Log, TEXT("no localcontroller >> OnPostLoadMap"));
    //    return;
    //}

    //���: OnPostLoadMap �Լ��� �� �ε� ���� ����������, ��Ʈ��ũ/�÷��̾�/��Ʈ�ѷ�/possession�� �ȳ��������� �ִ�.
    //AHBPlayerController* LocalHBPC = nullptr;

    //for (FConstPlayerControllerIterator It = World->GetPlayerControllerIterator(); It; ++It)
    //{
    //    UE_LOG(LogTemp, Log, TEXT("for������"));
    //    APlayerController* PC = It->Get();
    //    UE_LOG(LogTemp, Warning, TEXT("PC=%s Local=%d"), *GetNameSafe(PC), PC ? PC->IsLocalController() : -1);

    //    if (PC && PC->IsLocalController())
    //    {
    //        UE_LOG(LogTemp, Warning, TEXT("Local PC class = %s"), *GetNameSafe(PC->GetClass()));
    //        LocalHBPC = Cast<AHBPlayerController>(PC);
    //        UE_LOG(LogTemp, Warning, TEXT("Cast to AHBPlayerController = %s"), LocalHBPC ? TEXT("SUCCESS") : TEXT("FAIL"));
    //        break;
    //    }
    //}

    //if (!LocalHBPC)
    //{
    //    UE_LOG(LogTemp, Log, TEXT("OnPostLoadMap: LocalHBPC not found"));
    //    return;
    //}



    //LocalHBPC->ResetUI();
    //LocalHBPC->SetupUI();

}