// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "HBCharacterRole.h"
#include "HBCharacterStat.h"
#include "Components/ActorComponent.h"
#include "HBPlayerStatComponent.generated.h"


DECLARE_MULTICAST_DELEGATE_OneParam(FOnTotalTakenDamageChanged, float /*CurrentTotalDamage*/)
DECLARE_MULTICAST_DELEGATE_OneParam(FOnHealthChanged, int32 /* NightDamage */)
DECLARE_MULTICAST_DELEGATE_OneParam(FOnPlayerRoleChanged, ERoleType)
DECLARE_MULTICAST_DELEGATE_OneParam(FOnPlayerJobChanged, EJobType)
DECLARE_MULTICAST_DELEGATE_OneParam(FOnPlayerVoteNumChanged, int32)

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class HAPPYBEARVILLAGE_API UHBPlayerStatComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	// Sets default values for this component's properties
	UHBPlayerStatComponent();

protected:
	// Called when the game starts
	virtual void InitializeComponent() override;
	virtual void BeginPlay() override;

public:
	FOnTotalTakenDamageChanged OnTotalTakenDamageChanged;
	FOnHealthChanged OnHealthChanged;
	FOnPlayerRoleChanged OnPlayerRoleChanged;
	FOnPlayerJobChanged OnPlayerJobChanged;
	FOnPlayerVoteNumChanged OnPlayerVoteNumChanged;

public:
	// 스탯 관련 섹션 =====================================================================
	FORCEINLINE const FHBCharacterStat& GetBaseStat() const { return BaseStat; }
	FORCEINLINE float GetTotalTakenDamage() const { return TotalTakenDamage; }
	FORCEINLINE bool GetIsVoteTarget() const { return bIsVoteTarget; }
	FORCEINLINE bool GetIsAlive() const { return bIsAlive; }
	FORCEINLINE int32 GetVoteNum() const { return VoteNum; }
	FORCEINLINE int32 GetHealth() const { return Health; }

	FORCEINLINE void SetIsVoteTarget(bool InIsVoteTarget) { bIsVoteTarget = InIsVoteTarget; }
	FORCEINLINE void SetIsAlive(bool InIsAlive)
	{
		bIsAlive = InIsAlive;
		OnRep_IsAlive();
	}
	FORCEINLINE void SetHealth(int32 InHealth)
	{
		Health = InHealth;
		OnRep_Health();
	}

	float ApplyDamage(float InDamageAmount);
	int32 ApplyNightDamage();

	void ResetTotalTakenDamage();

	// 직업 관련 섹션 =====================================================================
	FORCEINLINE const FHBCharacterRole& GetCharacterRole() const { return CharacterRole; }

	// 캐릭터 직업 부여
	void InitCharacterRole();
	void InitCharacterRole(EJobType Job);

	// 캐릭터 직업 초기화
	void ResetCharacterRole();

	// 투표 관련 섹션 =====================================================================
	void ApplyVote(AActor* InActor);

protected:
	// 캐릭터 기본 스탯
	UPROPERTY(Transient, VisibleInstanceOnly, Category = Stat)
	FHBCharacterStat BaseStat;

	// 캐릭터 직업
	UPROPERTY(ReplicatedUsing = OnRep_CharacterRole, Transient, VisibleInstanceOnly, Category = Stat)
	FHBCharacterRole CharacterRole;

	// 난투 시 캐릭터가 받은 데미지
	UPROPERTY(ReplicatedUsing = OnRep_TotalTakenDamage, Transient, VisibleInstanceOnly, Category = Stat)
	float TotalTakenDamage = 0.f;

	// 투표 시 캐릭터가 받은 표
	UPROPERTY(ReplicatedUsing = OnRep_VoteNum, Transient, VisibleInstanceOnly, Category = Stat)
	int32 VoteNum = 0;

	UPROPERTY(ReplicatedUsing = OnRep_Health, Transient, VisibleAnywhere, Category = Stat)
	int32 Health = 2;

	UPROPERTY()
	TArray<AActor*> VotedPlayers;

	// 캐릭터 축출 대상 여부
	UPROPERTY(Replicated, Transient, VisibleInstanceOnly, Category = Stat)
	uint8 bIsVoteTarget : 1;

	// 캐릭터 생존 여부
	UPROPERTY(ReplicatedUsing = OnRep_IsAlive, Transient, VisibleInstanceOnly, Category = Stat)
	uint8 bIsAlive : 1;

protected:
	virtual void GetLifetimeReplicatedProps(TArray<class FLifetimeProperty>& OutLifetimeProps) const override;

	UFUNCTION()
	void OnRep_TotalTakenDamage();

	UFUNCTION()
	void OnRep_CharacterRole();

	UFUNCTION()
	void OnRep_VoteNum();

	UFUNCTION()
	void OnRep_Health();

	UFUNCTION()
	void OnRep_IsAlive();

private:
	// 투표한 인원 수 초기화
	void ClearVotedInfo();
};
