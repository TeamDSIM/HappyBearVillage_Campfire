// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/ScrollBox.h"
#include "Components/TextBlock.h"
#include "HBSteamFriendEntryWidget.h"
#include "GameState/HBMafiaGameState.h"
#include "HBLobbyWidget.generated.h"

/**
 * 
 */

class UMultiplayerSessionsSubsystem;
class UButton;
class APlayerState;

struct FHBSteamFriend;

UCLASS()
class HAPPYBEARVILLAGE_API UHBLobbyWidget : public UUserWidget
{
	GENERATED_BODY()

protected:
	virtual void NativeConstruct() override;
	virtual void NativeDestruct() override;
public:
	UFUNCTION()
	void SetFriendInviteVisible(bool bVisible);

private:

	UPROPERTY(meta = (BindWidget))
	UButton* StartButton;

	UPROPERTY(meta = (BindWidget))
	UButton* ExitButton;

	UFUNCTION()
	void StartButtonClicked();

	UFUNCTION()
	void ExitButtonClicked();

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox_Friends;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UTextBlock> LobbyScrollBoxTitle;

	UPROPERTY(meta = (BindWidget))
	TObjectPtr<UScrollBox> ScrollBox_LobbyPlayers;


	// Subsystem ĳ��
	UPROPERTY()
	TObjectPtr<UMultiplayerSessionsSubsystem> MultiplayerSessionsSubsystem;

	//��ģ�� �� �١� ���� BP Ŭ���� (WBP_FriendEntry)
	UPROPERTY(EditDefaultsOnly, Category = "Friends")
	TSubclassOf<UHBSteamFriendEntryWidget> FriendEntryWidgetClass;

	// ģ�� ��� ���� ��û
	void RequestFriends();

	// Subsystem���� ģ����� �б� �Ϸ� �� ȣ��� �Լ�
	void OnFriendsReady(const TArray<FHBSteamFriend>& Friends, bool bWasSuccessful);

	// FriendEntry���� ���ʴ롱 ������ �� ó��
	void HandleInviteClicked(const FString& NetIdStr);

	// �÷��̾� ��� ���� �Լ�
	UFUNCTION()
	void RefreshPlayersInRoom();

	// GameState ĳ��
	UPROPERTY()
	TObjectPtr<AHBMafiaGameState> CachedMafiaGS;

	//���� ƽ���� 1ȸ �� �����
	UFUNCTION()
	void HandleLobbyPlayersChanged();

};
